#include <stdio.h>
#include <string.h>
#include "funciones.h"

int main () {
    menu();
    return 0;
}